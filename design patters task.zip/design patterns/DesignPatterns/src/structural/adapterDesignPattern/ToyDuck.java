package structural.adapterDesignPattern;

public interface ToyDuck {
	public void squeak();
}
