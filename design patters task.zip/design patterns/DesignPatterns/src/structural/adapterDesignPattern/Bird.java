package structural.adapterDesignPattern;

public interface Bird {
	public void fly();
	public void makeSound();
}
