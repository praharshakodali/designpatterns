package structural.facadeDesignPattern;

public interface Shape {
	void display();
}
