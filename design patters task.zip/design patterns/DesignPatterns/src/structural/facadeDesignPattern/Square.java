/**
 * 
 */
package structural.facadeDesignPattern;

/**
 * @author harsha
 *
 */
public class Square implements Shape {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("This is square");
	}

}
