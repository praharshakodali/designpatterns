package structural.facadeDesignPattern;

public class FacadPatternDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ShapeMaker shapemaker = new ShapeMaker();
		shapemaker.displayCircle();
		shapemaker.displayRectangle();
		shapemaker.displaySquare();
	}

}
