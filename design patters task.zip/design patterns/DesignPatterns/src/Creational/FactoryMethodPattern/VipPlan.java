package Creational.FactoryMethodPattern;

public class VipPlan extends Plan {

	@Override
	void getRate() {
		// TODO Auto-generated method stub
		rate = 4.5;
	}

}
