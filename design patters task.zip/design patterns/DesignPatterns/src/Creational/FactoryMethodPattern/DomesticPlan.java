package Creational.FactoryMethodPattern;

public class DomesticPlan extends Plan {

	@Override
	void getRate() {
		// TODO Auto-generated method stub
		rate = 1.5;
	}

}
